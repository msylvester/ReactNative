
// using SendGrid's v3 Node.js Library
// https://github.com/sendgrid/sendgrid-nodejs
var helper = require('sendgrid').mail;
  
var from_email = new helper.Email("msylvest55@gmail.com");
var to_email = new helper.Email("mike@abstract.ai");
var subject = "Sending with SendGrid is Fun";
var content = new helper.Content("text/plain", "and easy to do anywhere, even with Node.js");
var mail = new helper.Mail(from_email, subject, to_email, content);

var sg = require('sendgrid')('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');
var request = sg.emptyRequest({
  method: 'POST',
  path: '/v3/mail/send',
  body: mail.toJSON()
});

sg.API(request, function(error, response) {
  console.log(response.statusCode);
  console.log(response.body);
  console.log(response.headers);



curl --request GET --url https://63i85sy2nc.execute-api.us-east-1.amazonaws.com/dev/ --header 'authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2Fic3RyYWN0YWkuYXV0aDAuY29tLyIsInN1YiI6Ik81Sm9Vb0psYnIzakQyeDB2aGREZjE1dFhVbnpqdVJiQGNsaWVudHMiLCJhdWQiOiJmZiIsImV4cCI6MTQ5MTE4NTc3MiwiaWF0IjoxNDkxMDk5MzcyLCJzY29wZSI6IiJ9.YNUCpoQCO_xNZZMFRiDxgfZITWeQ1jEF7QVfYhzo9E8'

curl --request GET --url https://svlv9jv5n0.execute-api.us-east-1.amazonaws.com/dev/ --header 'authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwczovL2Fic3RyYWN0YWkuYXV0aDAuY29tLyIsInN1YiI6Ik81Sm9Vb0psYnIzakQyeDB2aGREZjE1dFhVbnpqdVJiQGNsaWVudHMiLCJhdWQiOiJmZiIsImV4cCI6MTQ5MTE4NTc3MiwiaWF0IjoxNDkxMDk5MzcyLCJzY29wZSI6IiJ9.YNUCpoQCO_xNZZMFRiDxgfZITWeQ1jEF7QVfYhzo9E8'


mkdir fun-w-path && cd fun-w-path
serverless create --template aws-nodejs


export ApiGatewayEndpoint=" https://hjdmyj8250.execute-api.us-east-1.amazonaws.com/dev/"

curl -vvv -X POST -d '{"email": "your@mail.com", "phone": "0123456789"}' -H "Content-Type: application/json" https://$ApiGatewayEndpoint/user

curl -vvv -X POST -d '{"email": "your@mail.com", "phone": "0123456789"}' -H "Content-Type: application/json" https://hjdmyj8250.execute-api.us-east-1.amazonaws.com/dev/user

