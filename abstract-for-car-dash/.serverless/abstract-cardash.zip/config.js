'use strict';

module.exports = {
  awsAccountId: '985983045442',
};
